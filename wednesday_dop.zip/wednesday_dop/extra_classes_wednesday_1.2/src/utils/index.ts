export {generateRandomName} from './generateRandomName';
