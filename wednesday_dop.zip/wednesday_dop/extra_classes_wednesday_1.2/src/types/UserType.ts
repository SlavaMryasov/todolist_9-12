export type UserType = {
  id: string;
  name: string;
};
