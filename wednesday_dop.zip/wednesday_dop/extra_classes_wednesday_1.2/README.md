## Redux-flow

### Install dependency => yarn | yarn install
### Start project => yarn start

## YOU MUST KNOW IT
### Work progress redux, without async logic => https://rb.gy/urhzcc
### Work progress redux, with async logic => https://rb.gy/2wos1v
### Documentation https://redux.js.org/tutorials/fundamentals/part-6-async-logic

### Telegram: @gleb_pilipenka
### Good Luck (:
