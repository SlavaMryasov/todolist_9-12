### About composition, children, React.memo(), useMemo, useCallback

### Telegram: @gleb_pilipenka
### Good Luck (:
